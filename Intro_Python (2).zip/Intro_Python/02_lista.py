mochila = ["Canivete" , "Alicate" ,"Pá" , "Garrafa de agua"]
nums = [1,8,5,12,23,7]
# print(nums[2])
#Adicionar um elemento no fnal da lista 
nums.append(11)

for i in range(1,11):
    print(i)
    
for n in mochila:
    print(n)
    
for ferramenta in mochila:
    print(ferramenta, end = ", ")