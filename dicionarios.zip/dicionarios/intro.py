aluno = {
    'nome':'João Paulo',
    'naturalidade':'Portugagl',
    'peso':84,
    'aprovado': True
}

#imprimir uma chave do dicionario
print(aluno['naturalidade']) # Portugal
print(f'O aluno  {aluno['nome']} tem peso {aluno['peso']}kg.') # Portugal

# Caracteristicas do aluno 
for chave in aluno.keys():
    print(chave)

#Valores das chaves
for v in aluno.values():
    print(v)

# Par chave /valor
for k,v in aluno.items():
    print(f"{k}: {v}")
    
aluno['imc'] = round (aluno['peso'] / (aluno['altura'] * aluno['altura']),2)
aluno['naturalidade']= 'Itália'
print(aluno)