from django.shortcuts import render, redirect, get_object_or_404
from .models import Post, Autor, Categoria
from .forms import PostForm, AutorForm, CategoriaForm, FiltroForm


# ── POSTS ──────────────────────────────────────────────────────────────────────

def lista_posts(request):
    posts = Post.objects.select_related('autor', 'categoria').all()
    form_filtro = FiltroForm(request.GET)

    if form_filtro.is_valid():
        autor = form_filtro.cleaned_data.get('autor')
        categoria = form_filtro.cleaned_data.get('categoria')
        if autor:
            posts = posts.filter(autor=autor)
        if categoria:
            posts = posts.filter(categoria=categoria)

    return render(request, 'blog/lista_posts.html', {
        'posts': posts,
        'form_filtro': form_filtro,
    })


def detalhe_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'blog/detalhe_post.html', {'post': post})


def criar_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('lista_posts')
    else:
        form = PostForm()
    return render(request, 'blog/form_post.html', {'form': form, 'titulo': 'Novo Post'})


def editar_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('lista_posts')
    else:
        form = PostForm(instance=post)
    return render(request, 'blog/form_post.html', {'form': form, 'titulo': 'Editar Post'})


def eliminar_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == 'POST':
        post.delete()
        return redirect('lista_posts')
    return render(request, 'blog/confirmar_eliminacao.html', {'objeto': post, 'tipo': 'post'})


# ── AUTORES ────────────────────────────────────────────────────────────────────

def lista_autores(request):
    autores = Autor.objects.all()
    return render(request, 'blog/lista_autores.html', {'autores': autores})


def criar_autor(request):
    if request.method == 'POST':
        form = AutorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_autores')
    else:
        form = AutorForm()
    return render(request, 'blog/form_generico.html', {'form': form, 'titulo': 'Novo Autor'})


def editar_autor(request, pk):
    autor = get_object_or_404(Autor, pk=pk)
    if request.method == 'POST':
        form = AutorForm(request.POST, instance=autor)
        if form.is_valid():
            form.save()
            return redirect('lista_autores')
    else:
        form = AutorForm(instance=autor)
    return render(request, 'blog/form_generico.html', {'form': form, 'titulo': 'Editar Autor'})


def eliminar_autor(request, pk):
    autor = get_object_or_404(Autor, pk=pk)
    if request.method == 'POST':
        autor.delete()
        return redirect('lista_autores')
    return render(request, 'blog/confirmar_eliminacao.html', {'objeto': autor, 'tipo': 'autor'})


# ── CATEGORIAS ─────────────────────────────────────────────────────────────────

def lista_categorias(request):
    categorias = Categoria.objects.all()
    return render(request, 'blog/lista_categorias.html', {'categorias': categorias})


def criar_categoria(request):
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_categorias')
    else:
        form = CategoriaForm()
    return render(request, 'blog/form_generico.html', {'form': form, 'titulo': 'Nova Categoria'})


def editar_categoria(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        form = CategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            return redirect('lista_categorias')
    else:
        form = CategoriaForm(instance=categoria)
    return render(request, 'blog/form_generico.html', {'form': form, 'titulo': 'Editar Categoria'})


def eliminar_categoria(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        categoria.delete()
        return redirect('lista_categorias')
    return render(request, 'blog/confirmar_eliminacao.html', {'objeto': categoria, 'tipo': 'categoria'})
