#Exercicio 01
#Crie um programa que peça o comprimento e a largura 
# de um retãngulo e mostre a área e o perimetro

# comprimento = float(input("Digite o primeiro valor: "))
# largura = float(input("Digite o segundo valor: "))
# area = comprimento * largura
# perimetro = comprimento * 2 + largura * 2

# print(area)
# print(perimetro)


#Exercicio 02
#Crie uma lista com 10 numeros e imprima apenas os numeros pares 

# nums = [1,8,5,12,3,7,2,6,9,10]

# for n in nums:
#     if n % 2 == 0:
#         print(n)
   

#Exercicio 03 
#Crie um dicionario em que as chaves sejam nomes de produtos.
#Os valores sejam o preço de cada produto. 
#Deve devolver o produto mais caro e a média dos preços 

# produtos = {"Arroz": 1.66, "Bone":19.77, "Tenis":21.21}
# soma = 0
# preco_mais_caro = 0
# produto_mais_caro = ""
# for nome_produto, preco  in produtos.items():
#     soma = soma + preco 
#     if preco > preco_mais_caro:
#         preco_mais_caro = preco
#         produto_mais_caro = nome_produto
        
# media = soma / len(produtos)
# print("O produto mais caro é {produto_mais_caro}")
# print("Media dos preços {media:.2f}")

